from smarts.core.agent import AgentSpec
from smarts.core.agent_interface import AgentInterface
from smarts.core.controllers import ActionSpaceType
from smarts.zoo.registry import register


def make_agent_spec(
    gains={
        "theta": 2.125834022656066,
        "position": 1.0044327338178105,
        "obstacle": 1.5641815966588966,
        "u_accel": 0.40641492411819424,
        "u_yaw_rate": 0.9900987275823978,
        "terminal": 0.0,
        "impatience": 0.1,
        "speed": 0.0904143402122459,
    },
    debug=False,
    max_episode_steps=600,
):
    from .policy import Policy

    return AgentSpec(
        interface=AgentInterface(
            action=ActionSpaceType.Trajectory,
            waypoints=True,
            neighborhood_vehicles=True,
            max_episode_steps=max_episode_steps,
        ),
        policy_params={"gains": gains, "debug": debug,},
        policy_builder=Policy,
        perform_self_test=False,
    )


register(locator="open_agent-v0", entry_point=make_agent_spec)
