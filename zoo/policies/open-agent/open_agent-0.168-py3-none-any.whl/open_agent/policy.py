import logging
import os
import math

from dataclasses import dataclass

import casadi.casadi as cs
import numpy as np
import opengen as og

from smarts.core.agent import AgentPolicy
from smarts.core.coordinates import Heading
from smarts.core.utils import networking


VERSION = 168


def angle_error(a, b):
    return cs.fmin((a - b) ** 2.0, (a - (b + math.pi * 2.0)) ** 2.0)


@dataclass
class VehicleModel:
    """
    Based on the vehicle model defined here:
    http://planning.cs.uiuc.edu/node658.html
    """

    x: cs.SXElem
    y: cs.SXElem
    theta: cs.SXElem
    speed: cs.SXElem
    LENGTH = 4.0
    MAX_SPEED = 24.0  # m/s
    DOF = 4

    @property
    def as_xref(self):
        return XRef(x=self.x, y=self.y, theta=self.theta)

    def step(self, u: "U", ts):
        self.x += ts * self.speed * cs.cos(self.theta)
        self.y += ts * self.speed * cs.sin(self.theta)
        self.theta += ts * self.speed / self.LENGTH * u.yaw_rate
        self.speed += ts * u.accel
        self.speed = cs.fmin(self.MAX_SPEED, cs.fmax(0, self.speed))


@dataclass
class XRef:
    x: cs.SXElem
    y: cs.SXElem
    theta: cs.SXElem
    DOF = 3

    def weighted_distance_to(self, other: "XRef", Q_position=1.0, Q_theta=1.0):
        theta_err = angle_error(self.theta, other.theta)
        pos_err = (other.x - self.x) ** 2 + (other.y - self.y) ** 2
        return Q_position * pos_err + Q_theta * theta_err


@dataclass
class XRefTrajectory:
    x_ref_t: cs.SX

    def __getitem__(self, i):
        params = [self.x_ref_t[p] for p in range(i * XRef.DOF, i * XRef.DOF + XRef.DOF)]
        return XRef(*params)

    def __iter__(self):
        N = self.x_ref_t.size1() // XRef.DOF
        for i in range(N):
            yield self[i]

    def min_cost_by_distance(self, point: XRef, Q_position=1.0, Q_theta=1.0):
        x_ref_iter = iter(self)
        min_xref_t_cost = next(x_ref_iter).weighted_distance_to(
            point, Q_position=Q_position, Q_theta=Q_theta
        )
        for xref_t in x_ref_iter:
            min_xref_t_cost = cs.fmin(
                min_xref_t_cost,
                xref_t.weighted_distance_to(
                    point, Q_position=Q_position, Q_theta=Q_theta
                ),
            )

        return min_xref_t_cost


@dataclass
class U:
    accel: cs.SXElem
    yaw_rate: cs.SXElem


class UTrajectory:
    def __init__(self, N):
        self.N = N
        self.u = cs.SX.sym("u", 2 * N)

    @property
    def symbolic(self):
        return self.u

    def __getitem__(self, i):
        assert 0 <= i < self.N
        return U(accel=self.u[i * 2], yaw_rate=self.u[i * 2 + 1])

    def integration_cost(self, Q_integration_accel, Q_integration_yaw_rate):
        cost = 0
        for t in range(1, self.N):
            prev_u_t = self[t - 1]
            u_t = self[t]
            cost += Q_integration_accel * (u_t.accel - prev_u_t.accel) ** 2
            cost += Q_integration_yaw_rate * (u_t.yaw_rate - prev_u_t.yaw_rate) ** 2

        return cost


class Policy(AgentPolicy):
    def __init__(
        self,
        N=11,
        SV_N=4,
        WP_N=15,
        ts=0.1,
        Q_theta=10,
        Q_position=10,
        Q_obstacle=100,
        Q_u_accel=10,
        Q_u_yaw_rate=4,
        Q_n=4,
        Q_impatience=1,
        debug=False,
        retries=5,
    ):
        self.log = logging.getLogger(self.__class__.__name__)
        self.debug = debug
        self.step = 0
        self.last_position = None
        self.steps_without_moving = 0
        self.N = N
        self.SV_N = SV_N
        self.WP_N = WP_N
        self.ts = ts
        self.Q_theta = Q_theta
        self.Q_position = Q_position
        self.Q_obstacle = Q_obstacle
        self.Q_u_accel = Q_u_accel
        self.Q_u_yaw_rate = Q_u_yaw_rate
        self.Q_n = Q_n
        self.Q_impatience = Q_impatience
        self.retries = retries
        self.mng = None

        if self.debug:
            import matplotlib.pyplot as plt

            plt.ion()
            plt.show()

        self.init_planner()

    def init_planner(self):
        self.prev_solution = None
        build_dir = "OpEn_build"
        planner_name = "trajectory_optimizer"
        build_mode = "release"  # use "debug" for faster compilation times

        planner_name = f"{planner_name}_v{VERSION}"
        versioned_params = [
            self.N,
            self.SV_N,
            self.WP_N,
            self.ts,
            self.Q_theta,
            self.Q_position,
            self.Q_obstacle,
            self.Q_u_accel,
            self.Q_u_yaw_rate,
            self.Q_n,
            self.Q_impatience,
        ]
        params_str = "_".join(str(p) for p in versioned_params)
        build_dir = f"{build_dir}/{params_str}"
        path_to_planner = f"{build_dir}/{planner_name}"

        if not os.path.exists(path_to_planner):
            problem = self.build_problem()
            build_config = (
                og.config.BuildConfiguration()
                .with_build_directory(build_dir)
                .with_build_mode(build_mode)
                .with_tcp_interface_config()
            )
            meta = og.config.OptimizerMeta().with_optimizer_name(planner_name)
            solver_config = (
                og.config.SolverConfiguration()
                # TODO: hire interns to tune these values
                # .with_tolerance(1e-6)
                # .with_initial_tolerance(1e-4)
                # .with_max_outer_iterations(10)
                # .with_delta_tolerance(1e-2)
                # .with_penalty_weight_update_factor(10.0)
            )
            builder = og.builder.OpEnOptimizerBuilder(
                problem, meta, build_config, solver_config
            ).with_verbosity_level(1)
            builder.build()

        for i in range(self.retries):
            try:
                self.mng = og.tcp.OptimizerTcpManager(
                    path_to_planner, port=networking.find_free_port()
                )
                self.mng.start()
                break
            except Exception as e:
                self.log.warn(
                    f"Failed to start optimizer, attempt: {i + 1} / {self.retries}"
                )

        assert self.is_planner_running()

    def build_problem(self):
        # Assumptions
        assert self.N >= 2, f"Must generate at least 2 trajectory points, got: {self.N}"
        assert self.SV_N >= 0, f"Must have non-negative # of sv's, got: {self.SV_N}"
        assert self.WP_N >= 1, f"Must have at lest 1 trajectory reference"

        # TODO: rename WP_N to xref_n
        z0 = cs.SX.sym(
            "z0",
            VehicleModel.DOF + VehicleModel.DOF * self.SV_N + XRef.DOF * self.WP_N + 1,
        )
        u_traj = UTrajectory(self.N)

        ego_z0_range = z0[0 : VehicleModel.DOF]
        assert ego_z0_range.size1() == VehicleModel.DOF
        sv_z0_range = z0[
            ego_z0_range.size1() : ego_z0_range.size1() + VehicleModel.DOF * self.SV_N
        ]
        xref_z0_range = z0[
            ego_z0_range.size1()
            + sv_z0_range.size1() : ego_z0_range.size1()
            + sv_z0_range.size1()
            + XRef.DOF * self.WP_N
        ]
        impatience_z0_range = z0[
            ego_z0_range.size1()
            + sv_z0_range.size1()
            + xref_z0_range.size1() : ego_z0_range.size1()
            + sv_z0_range.size1()
            + xref_z0_range.size1()
            + 1
        ]

        ego = VehicleModel(*ego_z0_range.elements())
        social_vehicles = [
            VehicleModel(*sv_z0_range[sv_i : sv_i + VehicleModel.DOF].elements())
            for sv_i in range(0, sv_z0_range.size1(), VehicleModel.DOF)
        ]
        xref_traj = XRefTrajectory(xref_z0_range)
        impatience = impatience_z0_range[0]

        cost = 0

        for t in range(self.N):
            # Integrate the ego vehicle forward to the next trajectory point
            ego.step(u_traj[t], self.ts)

            # For the current pose, compute the smallest cost to any xref_t
            cost += xref_traj.min_cost_by_distance(
                ego.as_xref, Q_position=self.Q_position, Q_theta=self.Q_theta
            )

            for sv in social_vehicles:
                # step the social vehicle assuming no change in velocity or heading
                sv.step(U(accel=0, yaw_rate=0), self.ts)

                min_dist = VehicleModel.LENGTH
                cost += self.Q_obstacle * cs.fmax(
                    0, min_dist ** 2 - ((ego.x - sv.x) ** 2 + (ego.y - sv.y) ** 2),
                )

        # To stabilize the trajectory, we attach a higher weight to the final x_ref
        cost += xref_traj[-1].weighted_distance_to(
            ego.as_xref,
            Q_position=self.Q_position * self.Q_n,
            Q_theta=self.Q_theta * self.Q_n,
        )

        cost += u_traj.integration_cost(self.Q_u_accel, self.Q_u_yaw_rate)

        # force acceleration when we become increasingly impatient
        cost += self.Q_impatience * ((u_traj[0].accel - 1.0) * impatience ** 2 * -(1.0))

        bounds = og.constraints.Rectangle(
            xmin=[-1, -math.pi * 0.3] * self.N, xmax=[1, math.pi * 0.3] * self.N
        )

        return og.builder.Problem(u_traj.symbolic, z0, cost).with_constraints(bounds)

    def is_planner_running(self) -> bool:
        return self.mng and self.mng._OptimizerTcpManager__check_if_server_is_running()

    def stop_planner(self):
        if self.is_planner_running():
            # If the manager has already been killed through other means
            self.mng.kill()

            while self.is_planner_running():
                # wait for the optimizer to die
                time.sleep(0.1)

    def reinit_planner(self):
        self.prev_solution = None
        self.stop_planner()
        self.init_planner()

    def __del__(self):
        self.stop_planner()

    def act(self, obs):
        self.step += 1
        ego = obs.ego_vehicle_state
        if (
            self.last_position is not None
            and np.linalg.norm(ego.position - self.last_position) < 1e-1
        ):
            self.steps_without_moving += 1
        else:
            self.steps_without_moving = 0

        wps = min(obs.waypoint_paths, key=lambda wps: wps[0].dist_to(ego.position))

        # drop the first few waypoint to get the vehicle to move
        wps_to_skip = 3
        wps = wps[min(wps_to_skip, len(wps) - 1) : self.WP_N + wps_to_skip]

        # repeat the last waypoint to fill out self.WP_N waypoints
        wps += [wps[-1]] * (self.WP_N - len(wps))
        wps_params = [
            wp_param
            for wp in wps
            for wp_param in [wp.pos[0], wp.pos[1], float(wp.heading) + math.pi * 0.5]
        ]
        if self.SV_N == 0:
            sv_params = []
        elif len(obs.neighborhood_vehicle_states) == 0 and self.SV_N > 0:
            # We have no social vehicles in the scene, create placeholders far away
            sv_params = [
                ego.position[0] + 100000,
                ego.position[1] + 100000,
                0,
                0,
            ] * self.SV_N
        else:
            # Give the closest SV_N social vehicles to the planner
            social_vehicles = sorted(
                obs.neighborhood_vehicle_states,
                key=lambda sv: np.linalg.norm(sv.position - ego.position),
            )[: self.SV_N]

            # repeat the last social vehicle to ensure SV_N social vehicles
            social_vehicles += [social_vehicles[-1]] * (
                self.SV_N - len(social_vehicles)
            )
            sv_params = [
                sv_param
                for sv in social_vehicles
                for sv_param in [
                    sv.position[0],
                    sv.position[1],
                    float(sv.heading) + math.pi * 0.5,
                    sv.speed,
                ]
            ]

        ego_params = [
            ego.position[0],
            ego.position[1],
            float(ego.heading) + math.pi * 0.5,
            ego.speed,
        ]

        impatience = self.steps_without_moving
        planner_params = ego_params + sv_params + wps_params + [impatience]

        resp = self.mng.call(planner_params, initial_guess=self.prev_solution)

        if resp.is_ok():
            u_star = resp["solution"]
            self.prev_solution = u_star
            ego_model = VehicleModel(*ego_params)
            xs = []
            ys = []
            headings = []
            speeds = []
            for u in zip(u_star[::2], u_star[1::2]):
                ego_model.step(U(*u), self.ts)
                headings.append(Heading(ego_model.theta - math.pi * 0.5))
                xs.append(ego_model.x)
                ys.append(ego_model.y)
                speeds.append(ego_model.speed)

            traj = [xs, ys, headings, speeds]
            if self.debug and self.step % 3 == 0:
                import matplotlib.pyplot as plt

                plt.figure(211)
                plt.clf()
                plt.plot(xs, ys, "o-", color="xkcd:crimson", label="trajectory")
                wp_x = [wp.pos[0] for wp in wps]
                wp_y = [wp.pos[1] for wp in wps]
                plt.scatter(wp_x, wp_y, color="red", label="waypoint")

                sv_x = [sv_x for sv_x in sv_params[:: VehicleModel.DOF]]
                sv_y = [sv_y for sv_y in sv_params[1 :: VehicleModel.DOF]]
                plt.scatter(sv_x, sv_y, label="social vehicles")
                plt_radius = 35
                plt.axis(
                    (
                        ego.position[0] - plt_radius,
                        ego.position[0] + plt_radius,
                        ego.position[1] - plt_radius,
                        ego.position[1] + plt_radius,
                    )
                )
                plt.legend()
                plt.draw()

                plt.figure(212)
                plt.clf()
                u_ps = u_star[::2]
                u_thetas = u_star[1::2]
                ts = range(len(u_ps))
                plt.plot(ts, u_ps, "o-", color="gold", label="u_p")
                plt.plot(ts, u_thetas, "o-", color="purple", label="u_theta")
                plt.legend()
                plt.draw()

                plt.pause(1e-6)

            lookahead = 1
            act = [
                xs[lookahead],
                ys[lookahead],
                headings[lookahead],
                self.ts * lookahead,
            ]
        else:
            print("Bad resp. from planner:", resp.get().code)
            # re-init the planner and stay still, hopefully once we've re-initialized, we can recover
            self.reinit_planner()
            act = [*ego.position[:2], ego.heading, 10]

        self.last_position = ego.position
        return act
